class Aluno{
    constructor(matricula, nome, curso){
        this.matricula = matricula;
        this.nome = nome;
        this.curso = curso;
    }



}

module.exports=Aluno;