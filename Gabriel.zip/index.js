const express = require('express');
const app = express();
const Aluno = require("./Aluno");

/*
app.get("/alunos", function(req, res){
    res.send("Listagem de alunos");
});

app.get("/alunos/:matricula?", function(req, res){  //não precisa criar a rota simples e completa, com essa rota o usuário pode ou não colocar o valor da matricula.
    const mat = req.params.matricula;
    if (mat){
        res.send("Matricula de alunos: " + mat);
    } else{
        res.send("Listagem de alunos");
    }
    
});


app.get("/alunos/cadastrar", function(req, res){
    res.send("Cadastrar aluno");
});

*/


///////////
/*
a1 = new Aluno(1, 'joao', 'informatica');
a2 = new Aluno(2, 'gabriel', 'saneamento');
a3 = new Aluno(3, 'julio', 'eletronica');

vetor = [a1, a2, a3];

app.get("/alunos", function(req, res){
    res.send(vetor);
})
*/

const a1 = new Aluno('1', 'joao', 'informatica');
const a2 = new Aluno('2', 'gabriel', 'saneamento');
const a3 = new Aluno('3', 'julio', 'eletronica');
const alunos = [a1, a2, a3];

app.get("/alunos", function(req, res){
    
    for(let i of alunos){
        res.send(i);
    }


})

app.listen("999", function(){
    console.log("Rodando...");
})